package co.grandcircus.Lab22;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab22Application {

	public static void main(String[] args) {
		SpringApplication.run(Lab22Application.class, args);
	}

}
