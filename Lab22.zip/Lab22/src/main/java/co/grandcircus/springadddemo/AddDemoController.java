package co.grandcircus.springadddemo;




import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class AddDemoController {
	@RequestMapping("")
	public String Menu() {
		
		return "index";
	}
	
	@RequestMapping("/Anchovy-result")
	public String showPizza1() {
		
		
		return "Anchovy-result";
	}
	@RequestMapping("/name-result")
public String showName() {
		
		
		return "Name-result";
}
	@RequestMapping("/PaleoPizza-result")
	public String showPizza() {
		
		
		return "PaleoPizza-result";
	}
	@RequestMapping("/DessertPizza-result")
	public String showPizza2() {
		
		
		return "DessertPizza-result";
	}
	@RequestMapping("/CustomPizza-form")
	public String customPizzaForm() {
		
		
		
		
		return "CustomPizza-form";
	}
	@RequestMapping("/CustomPizza-result")
	public String customPizza(Model model,@RequestParam("pizza-size") String pizzaSize,
			@RequestParam("number") int toppings,
			@RequestParam("gluten") boolean g){
			 
		model.addAttribute("size", pizzaSize);
		model.addAttribute("topping", toppings);
		model.addAttribute("Gluten", g);
		
		return "CustomPizza-result";
		
	}

}


