package co.grandcircus.springadddemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringAddDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringAddDemoApplication.class, args);
	}

}
